package com.psl.loops;

public class Break_condt {
	public static void main(String[] args) {
		
		
			int []a={1,2,3,4,5,6};
			
			System.out.println("with break:");
			//it breaks the loop after condition satisifies it comes out of the loop
			int i ;
			for(i=1;i<a.length;i++)
			{
				if(i%3==0)
				
					break; //if in {} break cannot have a statement after that CE-->uncreachable code

					System.out.println("number divisible by 3="+i);
				
			}
			
			
			
			
			
			//doesnt come out of the loop it skips where the condition matches
			System.out.println("with Continue");
			int j ;
			for(j=1;j<a.length;j++)
			{
				if(j%3==0)
				
						continue;
						System.out.println("number divisible by 3="+j);//if in {} continue cannot have a statement after that CE-->uncreachable code


						
				
			}
			
			//incase of nested loops when  break encounters it il only exit the inner loop not the outer
			String [] subject={"c++","java"};
			
			for(String outer:subject)
				for(String inner:subject){
					
					if(inner.equals("java"))
						break;
					System.out.println(inner);
				}	
			
	}
}
