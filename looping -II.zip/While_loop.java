package com.psl.loops;

public class While_loop {
	public static void main(String[] args) {
		
		//argument should only be boolean or Boolean no dclaration inside
	/*	while(int i=10)
			System.out.println(i);
			*/
		
		
		
		//while(int j=15>10); //	CE-->delete token int
			
			
		int i=0;
		while( 5>i)
			System.out.println(i++); //only first line is part of while w/o{}
			System.out.println("not inside the loop"); //executed only once not a part of while
			
		
		int k=0;
		while(5>k){
			System.out.println(k);
			k++;
		}
		
		int num=9;
		Boolean b=false;
		while(!b){
			
			if(num % 7==0)
				b=true; //only part of if
			System.out.println(num);
			num--;
			
		}
		
		//wont enter the loop
		boolean h=true;
		while(h==false){
			System.out.println("hi");
		}
		
		//wont enter the loop
		boolean p=false;
		while(p==h){
			System.out.println("abc");
		}
		
		
		
	}
}