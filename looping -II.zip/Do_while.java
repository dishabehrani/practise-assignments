package com.psl.loops;

import java.util.stream.Stream;

public class Do_while {
	public static void main(String[] args) {
		
		
	/*	
		
		//no declaration inside while as i cant be resolved
		do
		{
			 
		}while(int i=9>5) //semi colon expected
		
		
		
		int j=1;
		do{
			
			
			System.out.println(j); //if we dont update j infinite loop 1
		}while(j<5);
		
		*/
		

		int j=1;
		do{
			
			
			System.out.println(j); //if we dont update j infinite loop 1
			j++;
		}while(j<5);
		
		
		int k=5;
		do
			System.out.println(k--);
			//System.out.println("hi"); //CE->insert while to	 complete statement	
		while(k>0);
		
		
		//use {} for a block of code
		int l=5;
		do
		{
			System.out.print("hi:");
			System.out.println(l-- );
		}while(l>0);
		
	}

}
