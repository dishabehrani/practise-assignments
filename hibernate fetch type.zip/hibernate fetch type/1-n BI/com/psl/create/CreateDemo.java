package com.psl.create;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.entity.Course;
import com.psl.entity.Instructor;
import com.psl.entity.InstructorDetail;

public class CreateDemo {
	
	public static void main(String[] args) {
		
		
		SessionFactory factory=new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Instructor.class)
								.addAnnotatedClass(InstructorDetail.class)
								.addAnnotatedClass(Course.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		try{
			
			
			session.beginTransaction();
		
//			Instructor  instructor=new Instructor("disha", "behrani","disha.behrani@gmail,com");
//			InstructorDetail detail=new InstructorDetail("disha@youtube.com","sing");
//			instructor.setDetail(detail);
//			session.save(instructor);

			
			//get the instructor to whom we want to add course 
			//as its a bi-directional link 
			int id=1;
			Instructor instructor=session.get(Instructor.class, id);
			
			
			
			//create course
			Course course1=new Course("oracle");
			Course course2=new Course("java");
					
			//add to this instructor using method add
			instructor.add(course1);
			instructor.add(course2);
			
			
			//add courses 
			session.save(course1);
			session.save(course2);
			
			
			
			
			
			session.getTransaction().commit();
			
			
			
		}
		catch(Exception e)
		{
			}
		finally
		{

			session.close();
			factory.close();
		
		}
	}

}
