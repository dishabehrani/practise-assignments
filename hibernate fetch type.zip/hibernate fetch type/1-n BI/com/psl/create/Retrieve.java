package com.psl.create;

import javax.persistence.criteria.CriteriaBuilder.In;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.entity.Course;
import com.psl.entity.Instructor;
import com.psl.entity.InstructorDetail;

public class Retrieve {
	
	public static void main(String[] args) {
		
		
		SessionFactory factory=new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Instructor.class)
								.addAnnotatedClass(InstructorDetail.class)
								.addAnnotatedClass(Course.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		try{
			
			
			session.beginTransaction();
	
			//get a instructor
			
			int id=1;
			Instructor instructor=session.get(Instructor.class, id);
			
			
			//print course details for instuctor with id =1
			System.out.println(instructor.getCourse());
			session.getTransaction().commit();
			
			
			
		}
		catch(Exception e)
		{
			}
		finally
		{

			session.close();
			factory.close();
		
		}
	}

}
