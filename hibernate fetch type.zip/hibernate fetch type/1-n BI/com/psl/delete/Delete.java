package com.psl.delete;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.entity.Course;
import com.psl.entity.Instructor;
import com.psl.entity.InstructorDetail;

public class Delete {

	

	public static void main(String[] args) {
		
		
		SessionFactory factory=new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Instructor.class)
								.addAnnotatedClass(InstructorDetail.class)
								.addAnnotatedClass(Course.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		try{
			
			
			session.beginTransaction();
		
			//delete both
			int id =10;
			
			//as we didn't include cascaseType .DELETE it will only delete the course and not the linked instructor
			Course course=session.get(Course.class, id);
			
			
			
			
			session.delete(course);
			
			session.getTransaction().commit();
			
			
			
		}
		catch(Exception e)
		{
			
		}
		finally
		{
			session.close();
			factory.close();
	
		}

	}
}
