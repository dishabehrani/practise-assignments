package com.psl.create;

import javax.persistence.criteria.CriteriaBuilder.In;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.entity.Course;
import com.psl.entity.Instructor;
import com.psl.entity.InstructorDetail;
import com.psl.entity.Review;

public class Retrieve {
	
	public static void main(String[] args) {
		
		
		SessionFactory factory=new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Instructor.class)
								.addAnnotatedClass(InstructorDetail.class)
								.addAnnotatedClass(Course.class)
								.addAnnotatedClass(Review.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		try{
			
			
			session.beginTransaction();
	
			//get a course
			int id=10;
			Course course=session.get(Course.class,10 );
			
			//as it was  a lazy fetch ,we need to explicitly call for reiviews
			System.out.println(course.getReview());
			
			
			session.getTransaction().commit();
			
			
			
		}
		catch(Exception e)
		{
			}
		finally
		{

			session.close();
			factory.close();
		
		}
	}

}
