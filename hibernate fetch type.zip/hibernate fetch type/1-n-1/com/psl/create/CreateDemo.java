package com.psl.create;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.entity.Course;
import com.psl.entity.Instructor;
import com.psl.entity.InstructorDetail;
import com.psl.entity.Review;

public class CreateDemo {
	
	public static void main(String[] args) {
		
		
		SessionFactory factory=new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Instructor.class)
								.addAnnotatedClass(InstructorDetail.class)
								.addAnnotatedClass(Course.class)
								.addAnnotatedClass(Review.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		try{
			
			
			session.beginTransaction();
			//create course 
			
			Course course=new Course("joy of computing");
			
			//create reviews
			course.add(new Review("good"));
			course.add(new Review("best"));
			
			System.out.println("course:"+course);
			System.out.println("reviews:"+course.getReview());
			
			
			//saves the cousre and the reviews as cascade type is all
			session.save(course);
			
			System.out.println();
		
			
			
			
			session.getTransaction().commit();
			
			
			
		}
		catch(Exception e)
		{
			}
		finally
		{

			session.close();
			factory.close();
		
		}
	}

}
