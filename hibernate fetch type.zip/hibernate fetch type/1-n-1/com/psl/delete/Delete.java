package com.psl.delete;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.entity.Course;
import com.psl.entity.Instructor;
import com.psl.entity.InstructorDetail;
import com.psl.entity.Review;

public class Delete {

	

	public static void main(String[] args) {
		
		
		SessionFactory factory=new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Instructor.class)
								.addAnnotatedClass(InstructorDetail.class)
								.addAnnotatedClass(Course.class)
								.addAnnotatedClass(Review.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		try{
			
			
			session.beginTransaction();
		
			//delete both
			int id =10;
			
			//as we didn't include cascaseType .All it will  delete the course and  the linked reviews
			Course course=session.get(Course.class, id);
			
			
			
			
			session.delete(course);
			System.out.println("deleted course and reviews");
			
			session.getTransaction().commit();
			
			
			
		}
		catch(Exception e)
		{
			
		}
		finally
		{
			session.close();
			factory.close();
	
		}

	}
}
