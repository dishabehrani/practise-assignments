package com.psl.create;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.entity.Course;
import com.psl.entity.Instructor;
import com.psl.entity.InstructorDetail;
import com.psl.entity.Review;
import com.psl.entity.Student;


public class DeleteStudent {

	
	public static void main(String[] args) {
		
		
		SessionFactory factory=new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Instructor.class)
								.addAnnotatedClass(InstructorDetail.class)
								.addAnnotatedClass(Review.class)
								.addAnnotatedClass(Course.class)
								.addAnnotatedClass(Student.class)
								.buildSessionFactory();
		Session session=factory.getCurrentSession();
		
		
		try{
			
			
			session.beginTransaction();
			
			//get student to list courses			
			Student student=session.get(Student.class, 4);
		
			
			session.delete(student);
		
			
			session.getTransaction().commit();
		}
		catch(Exception e)
		{
			
		}
		finally {
			factory.close();
		}
	}

}
