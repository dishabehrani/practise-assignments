package com.psl.create;

import javax.persistence.criteria.CriteriaBuilder.In;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.entity.Course;
import com.psl.entity.Instructor;
import com.psl.entity.InstructorDetail;

public class closeSession {
	
	public static void main(String[] args) {
		
		
		SessionFactory factory=new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Instructor.class)
								.addAnnotatedClass(InstructorDetail.class)
								.addAnnotatedClass(Course.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		try{
			
			
			session.beginTransaction();
			System.out.println("session open");
			//get a instructor
			int id=1;
			Instructor instructor=session.get(Instructor.class, id);
			
			System.out.println("instructor info="+instructor);
			
			//once loaded at open session will be available even when closed
			System.out.println("courses"+instructor.getCourse());
			
			//print course details for instructor with id =1
			session.getTransaction().commit();
			
			session.close();
			
			
			System.out.println("session closed");
			//as its lazy loading after session closes it will throw an error as it not loaded earlier
			//RE->LazyInitializationException--failed to load courses,
			//how to resolve it-->
			//case 1- call the getter method when session is open ,it will loaded and then when called during session 
			//is close it wont raise an exception
 			System.out.println("courses="+instructor.getCourse());
			
		}
		
		finally
		{

			factory.close();
		
		}
	}

}
