package com.psl.create;

import javax.persistence.criteria.CriteriaBuilder.In;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.entity.Course;
import com.psl.entity.Instructor;
import com.psl.entity.InstructorDetail;

public class Retrieve {
	
	public static void main(String[] args) {
		
		
		SessionFactory factory=new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Instructor.class)
								.addAnnotatedClass(InstructorDetail.class)
								.addAnnotatedClass(Course.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		try{
			
			
			session.beginTransaction();
	
			//get a instructor
			//as its eager loading fetches Instructor ,instructor ,courses
			//as its lazy loading it detches only instructor and instructor detail but not courses
			int id=1;
			Instructor instructor=session.get(Instructor.class, id);
			
			System.out.println("instructor info="+instructor);
			
				session.getTransaction().commit();
				session.close();
				
				//print course details for instructor with id =1
				//eager ,it doesnt hit the Db ,retieve from memory
				//lazy ,it will hit db as its on demand loading
				System.out.println("courses="+instructor.getCourse());
			
			
			
		}
		catch(Exception e)
		{
			}
		finally
		{

			factory.close();
		
		}
	}

}
