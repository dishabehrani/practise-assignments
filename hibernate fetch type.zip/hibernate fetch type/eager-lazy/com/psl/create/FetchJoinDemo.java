package com.psl.create;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.entity.Course;
import com.psl.entity.Instructor;
import com.psl.entity.InstructorDetail;



public class FetchJoinDemo {
	
	public static void main(String[] args) {
		
		
		SessionFactory factory=new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Instructor.class)
								.addAnnotatedClass(InstructorDetail.class)
								.addAnnotatedClass(Course.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		try{
			
			
			session.beginTransaction();
			
			//use HQL to get instructor from db
int id=1;
			Query<Instructor> query=session.createQuery("select i from Instructor i"+
					" JOIN Fetch i.course"+
					"  where i.id=:ins",Instructor.class);
			
			query.setParameter("ins", id);
			Instructor t=query.getSingleResult();
			System.out.println(t);
			
			session.getTransaction().commit();
			
			session.close();
			
			System.out.println(t.getCourse());
		
		}
		catch(Exception e)
		{
			}
		finally
		{

			factory.close();
		
		}
	}

}
