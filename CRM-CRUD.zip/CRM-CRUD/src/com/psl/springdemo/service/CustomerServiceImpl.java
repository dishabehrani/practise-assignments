package com.psl.springdemo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.psl.springdemo.dao.CustomerDAO;
import com.psl.springdemo.entity.Customer;


@Service
public class CustomerServiceImpl implements CustomerService {

	//need to inject customer DAO
	@Autowired
	private CustomerDAO dao;
	
	
	@Transactional
	public List<Customer> getCustomers() {
		
		
		return dao.getCustomers();
	}


	@Transactional
	public void saveCustomer(Customer customer) {
		
		
		dao.saveCustomer(customer);
		
	}


	@Transactional
	public Customer getCustomer(int id) {
		return dao.getCustomer(id);
	}
	@Transactional
	public void deleteCustomer(int id) {
		
		
		dao.deleteCustomer(id);
		
	}
	
	
}
