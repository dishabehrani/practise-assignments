package com.psl.overloading;

public class Parent_childobj {
	
	public void m1(String s)
	{
		System.out.println("string arg");
	}
	
	public void m1(Object o)
	{
		System.out.println("object arg");
	}
	
	
	
	public static void main(String[] args) {
		
	Parent_childobj p=new Parent_childobj();
	p.m1(new String ("disha"));  //direct match
	p.m1(new Object());   //direct  match
	p.m1(new StringBuilder("abc")); //if no direct found it promotes
	 
	
	//case 1-parent child --->child wins
	p.m1(null);  //string arg-->valid for both Parent(object) as well as Child(String) always go for  --->CHILD
	
	
	}
}
