package com.psl.overloading;

public class Child2parent1 {
	
	
	public void m1(StringBuilder sb)
	{
		System.out.println("String builder arg");
	}
	public void m1(String s)
	{
		System.out.println("string arg");
	}
	public static void main(String[] args) {
		
	
	Child2parent1 c=new Child2parent1();
	
	c.m1("a"); //direct match string
	c.m1(new String("disha")); //direct match string
	
	c.m1(new StringBuilder("pdq")); //direct match string builder
	
	//case 2- in case of 2 childs of same parent  CE->none of the child  wins
	//c.m1(null); //CE-> m1 ()is of ambiguious type
	}

}
