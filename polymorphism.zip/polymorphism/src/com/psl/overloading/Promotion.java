package com.psl.overloading;




public class Promotion {
	
	public void m1(int i){
		System.out.println("int -arg");
	}
	
	public void m1(float f){
		System.out.println("float -arg");
	}
	
	public static void main(String[] args) {
		
		
		Promotion p=new Promotion();
		
		p.m1(10); //direct match
		p.m1(10.6f); //direct match
		p.m1(10l); //long->float
		p.m1('a'); //char->int
		//p.m1(10.5); //CE->not applicable for double arg
		
	}	
	

}
