package com.psl.overloading;



 class Animal{
	
}
 
 class Monkey extends Animal{
	 
 }
public class Compiletime_ref {
	 
	 public void m1(Animal a){
		 System.out.println("animal");
	 }
	
	public void m1(Monkey m){
		 System.out.println("monkey");
	 }
	
	public static void main(String[] args) {
		
		Compiletime_ref c=new Compiletime_ref();
		
		
		//case 1->parent=ref and  parent=obj
		Animal a =new Animal();
		c.m1(a); //direct match-->animal
	
		//case 2->child=ref child=obj
		Monkey m=new Monkey();
		c.m1(m);// direct match -->monkey
				
		//case 3 ->parent=ref child=obj
		Animal a1 =new Monkey();
		c.m1(a1); // animal   indirectly--->ref obj always wins
	}
}

