package com.psl.overloading;

public class Double_arg {
public static void main(String[] args) {
	
}
}
