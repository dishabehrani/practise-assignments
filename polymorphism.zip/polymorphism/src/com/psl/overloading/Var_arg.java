package com.psl.overloading;

public class Var_arg {
	public void m1(int x)
	{
		System.out.println("general");
	}
	
	public void m1(int...x )
	{
		System.out.println("var args");
	}
	public static void main(String[] args) {
		Var_arg v=new Var_arg();
		
		//general wins over var arg
		v.m1(10); //genral
		v.m1(); //var-arg as no arg
		v.m1(10,12); //var -arg
		
	}

}
