package com.psl.localdate;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;

public class Operations {
	
	public static void main(String[] args) {
	

		//LocalDate date1=LocalDate.of(1997,2,90);//invalid date
		LocalDate date2=LocalDate.of(1997,Month.JULY,07);
		LocalDate date1=LocalDate.of(1997,01,31);
		//LocalDate date1=LocalDate.of(1997,01,107); //DateTimeException
		
		
		System.out.println("date1="+date1);
		System.out.println(date2);
		System.out.println(date1.getClass().getName()); //java.time.LocalDate
		
		//system clock
		System.out.println("Now="+LocalDate.now());
		
		
		//parse-String to LocalDate
		//LocalDate date3=LocalDate.parse("2019/04/10"); //DateTimeParseException
		//LocalDate date3=LocalDate.parse("2019-04-0"); //double didgit for month and date
		LocalDate date3=LocalDate.parse("2019-04-10");
		System.out.println("parsed="+date3);
		

		//get function
		System.out.println("GET FUNCTION");
		System.out.println(date1.getDayOfMonth());
		System.out.println(date1.getDayOfWeek());
		System.out.println(date1.getDayOfYear());
		System.out.println(date1.getMonthValue()); //jan is 1 not 0
		System.out.println(date1.getYear());
		System.out.println(date1.getMonth());
		
		
		//isBefore()  isAfter()
		System.out.println("before after");
		System.out.println(date1.isBefore(date2));
		System.out.println(date1.isAfter(date2));
		
		//minus
		System.out.println("minus-->");
		System.out.println(date1.minusDays(1));
		System.out.println(date1.minusMonths(2));
		System.out.println(date1.minusWeeks(1));
		System.out.println(date1.minusYears(2));
		

		//plus
		System.out.println("plus=-->");
		System.out.println(date1.plusDays(1));
		System.out.println(date1.plusMonths(2));
		System.out.println(date1.plusWeeks(1));
		System.out.println(date1.plusYears(2));
		
		
		//with functions replaces what is specified
		System.out.println("with functions");
		System.out.println(date1.withDayOfMonth(7));
		System.out.println(date1.withDayOfYear(32));
		System.out.println(date1.withMonth(7));
		System.out.println(date1.withYear(2020));
		
		
		
		//at time 
		System.out.println("at time functions");
		
		System.out.println(date1.atTime(15, 2));
		System.out.println(date1.atTime(15, 2, 12));
		System.out.println(date1.atTime(15, 2, 12,300));

		System.out.println(date1.atTime(LocalTime.of(15, 2)));
		//System.out.println(date1.atTime(LocalTime.of(14,120))); //DateTimeException
		System.out.println(date1.atTime(LocalTime.of(15, 2, 12)));

		System.out.println(date1.atTime(LocalTime.of(15, 2, 12,200)));
		
		
		
		
		
		
		
		
		
		//epoch date= 1 jan 1970     
		System.out.println("epoch");
		LocalDate date4=LocalDate.of(1970, 1, 2);
		System.out.println(date4.toEpochDay());
		
		//LocalDte is immutable it returns a copy of LD instance on which its called
		System.out.println("date1="+date1);
		}
}
