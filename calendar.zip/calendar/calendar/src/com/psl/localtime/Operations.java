package com.psl.localtime;
import java.time.LocalDate;
import java.time.LocalTime;

public class Operations {

	
	public static void main(String[] args) {
		
		
		//LocalTime time1=LocalTime.of(190987458964984894, 12);//CE->literal is out of int range
		//LocalTime time2=LocalTime.of(120, 12);//RE->DateTimeException invalid value for HourOfDay
		 
		//-ve value not accpected RE
		LocalTime time1=LocalTime.of(22, 6,6,9999); //hr(0-23) min(0-59) sec(0-59)
		System.out.println(time1);
		
		//System time
		System.out.println("system time="+LocalTime.now());
		
		//parse string to time format only in this format (hr:min:sec) complusory in 2-digits 
		//throws only RE->DateTimeParseException
	
		
		LocalTime time2=LocalTime.parse("02:02:02");  
		//LocalTime time2=LocalTime.parse("0452:02:02");  
		//LocalTime time2=LocalTime.parse("02-02:02");  
		//LocalTime time2=LocalTime.parse("02:2:02");  
		
		System.out.println(time2);

		
		
		
		//constants for Localtime class
		
		System.out.println("contants ->");
		System.out.println("max="+LocalTime.MAX); //23:59:59.999999999
		System.out.println("min="+LocalTime.MIN); //00:00
		System.out.println("noon="+LocalTime.NOON); // 12:00
		System.out.println("midnight="+LocalTime.MIDNIGHT); //00:00
		
		System.out.println(LocalTime.MIN.equals(LocalTime.MIDNIGHT));
		
		
		//get function
		System.out.println("GET FUNCTION-> for 22, 6,6,9999");
		System.out.println("hour="+time1.getHour());
		System.out.println("min="+time1.getMinute());
		System.out.println("sec="+time1.getSecond());
		System.out.println("nano sec="+time1.getNano());
		
		//isBefore isAfter
		System.out.println(time1.isBefore(time2));
		System.out.println(time1.isAfter(time2));
		
		//minus
		System.out.println("minus from time->22, 6,6,9999");
		System.out.println(time1.minusHours(21));
		System.out.println(time1.minusHours(23)); //23:06:06.000009999 goes back
		System.out.println(time1.minusMinutes(56)); //21:10:06.000009999 goes back
		System.out.println(time1.minusSeconds(2));
		System.out.println(time1.minusSeconds(8));//22:05:58.000009999
		System.out.println(time1.minusNanos(500));
		System.out.println(time1.minusNanos(10000));//22:06:05.999999999
	
		//plus
		System.out.println("plus from time->22, 6,6,9999");
		System.out.println(time1.plusHours(21));
		System.out.println(time1.plusHours(2)); 
		System.out.println(time1.plusMinutes(56)); 
		System.out.println(time1.plusSeconds(2));
		System.out.println(time1.plusSeconds(8));
		System.out.println(time1.plusNanos(500));
		System.out.println(time1.plusNanos(10000));
		
		//with
		System.out.println("with time->22, 6,6,9999");
		//System.out.println(time1.withHour(1000000000000000));//CE->literal is out of int range
		//System.out.println(time1.withHour(100));//RE->DateTimeExcepiton
		System.out.println(time1.withHour(11));
		System.out.println(time1.withMinute(6));
		System.out.println(time1.withNano(12990));
		System.out.println(time1.withSecond(54));
		
		
		//combine with date
		System.out.println("combine with date-->");
		System.out.println(time1.atDate(LocalDate.of(1012, 1,31)));
		LocalDate date1=LocalDate.of(2017,7,7);
		System.out.println(time1.atDate(date1));
		
		
	}
}
 