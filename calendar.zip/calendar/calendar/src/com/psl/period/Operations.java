package com.psl.period;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;

public class Operations {

	public static void main(String[] args) {
		
		
		//int argument -ve also accepted
		//format 	P-Y-M-D
	
		Period p=Period.of(2,1,1);
		System.out.println(p);
		System.out.println(Period.ofYears(1));
		System.out.println(Period.ofYears(-1));
		System.out.println(Period.ofDays(100));
		System.out.println(Period.ofMonths(12));
		System.out.println(Period.ofWeeks(1)); //P7D gives in days
		
		
		
		System.out.println(Period.parse("P7y"));
		//System.out.println(Period.parse("P7y7D7m")); //sequenece matters pymd
		System.out.println(Period.parse("+P7y"));
		System.out.println(Period.parse("-P7y"));
		System.out.println(Period.parse("+P7y-7m7d"));

		System.out.println(Period.parse("-P7y-7m+7d")); //follow ++ +- -+ --
		
		//end(excluding) -start(inclusive)
		Period in_between=Period.between(LocalDate.of(2017, 7, 7),(LocalDate.of(2016, 7, 8)));
		Period in_between1=Period.between(LocalDate.of(2017, 12, 7),(LocalDate.of(2018, 7, 7)));
		
		System.out.println(in_between);
		System.out.println(in_between1);
		
		
		//get
		System.out.println(p.getYears());
		System.out.println(p.getMonths());
		System.out.println(p.getDays());

		//minus plus applicable for LocalDate and LocalDat
		LocalDate date1=LocalDate.of(2012,1,1);
		System.out.println(date1.minus(Period.of(1, 1,1)));
		System.out.println(date1.minus(Period.ofDays(10)));
		System.out.println(date1.minus(Period.ofMonths(12)));
		System.out.println(date1.minus(Period.ofYears(-11)));//-- = +
		
		LocalDateTime date12=LocalDateTime.of(2012,1,1,12,12,12,1345);
		System.out.println(date12.minus(Period.of(1, 1,1)));
		System.out.println(date12.minus(Period.ofDays(10)));
		System.out.println(date12.minus(Period.ofMonths(12)));
		System.out.println(date12.plus(Period.ofYears(-11))); //+- == -
		
		
		
		//for iszero ->all should should be zero
		//forisnegaive ->atleast 1 should be less than 0
		Period p1=Period.of(0,0, 0);
		Period p2=Period.of(0,1,- 2);
		System.out.println(p1.isZero());
		System.out.println(p1.isNegative());
		System.out.println(p2.isZero());
		System.out.println(p2.isNegative());
		
		//multiplies all the units
		System.out.println(p.multipliedBy(2));
		//p->2y1m1d
		System.out.println(p.plus(p1));
		System.out.println(p.plusDays(1));
		System.out.println(p.plusMonths(-8));
		System.out.println(p1.plusMonths(-10)); // +- =-
		System.out.println(p.plusYears(12));
	
		System.out.println(p.minus(p1));
		System.out.println(p.minusDays(-1));
		System.out.println(p.minusMonths(-8));//--=+
		System.out.println(p1.minusMonths(-10)); // -- =+
		System.out.println(p.minusYears(12));
		
		System.out.println(p.toTotalMonths()); // Y*12+M
		
	}
}
