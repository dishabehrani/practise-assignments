package com.psl.localdatetime;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;

public class Operations {
	public static void main(String[] args) {
		
		//Format year-mon-dayThr:min:sec:nano
		LocalDate date1=LocalDate.of(2020,2,12);
		LocalTime time1=LocalTime.of(22, 21);
		
		//LocalDate and LocaLTime as argument separated  by T
		LocalDateTime dt1=LocalDateTime.of(date1,time1);

		//all arguments are int or month -enum
		LocalDateTime dt2=LocalDateTime.of(2012,Month.JULY, 7, 00, 00, 00, 1);
		System.out.println(dt1);
		System.out.println(LocalDateTime.of(2019, 7,7,00, 00));
		System.out.println(LocalDateTime.of(2012,Month.JULY, 7, 00, 00, 00, 1));
		
		
		
		System.out.println(LocalDateTime.now());
		System.out.println(LocalDateTime.MAX);	
		System.out.println(LocalDateTime.MIN);	
		//System.out.println(LocalDateTime.NOON); //NA for LocalDateTime class
		//System.out.println(LocalDateTime.MIDNIGHT);
		
		
		
		//true or false
		System.out.println(dt1.isAfter(dt2));
		System.out.println(dt1.isBefore(dt2));
		
		//return int or month enum
		dt1.getDayOfMonth();
		dt1.getDayOfWeek();
		dt1.getDayOfYear();
		dt1.getMonth();
		dt1.getMonthValue();
		dt1.getYear();
		dt1.getHour();
		dt1.getMinute();
		dt1.getSecond();
		System.out.println(dt1.getMonth());
		
		//int argument
		dt1.withDayOfMonth(12);
		dt1.withDayOfYear(100);
		dt1.withMonth(12);
		dt1.withYear(2012);
		dt1.withHour(12);
		dt1.withMinute(12);
		dt1.withSecond(12);
		dt1.withNano(12);
		//System.out.println(dt1.withDayOfYear(201));//valid range 366-365 adds201 days to day
		
		//long argument
		dt1.minusDays(12);
		dt1.minusMonths(12);
		dt1.minusWeeks(12);
		dt1.minusYears(20);
		dt1.minusHours(12);
		dt1.minusMinutes(12);
		dt1.minusSeconds(12);
		dt1.minusNanos(12);
		
		//long argument
		dt1.plusDays(12);
		dt1.plusMonths(12);
		dt1.plusWeeks(12);
		dt1.plusYears(20);
		dt1.plusHours(12);
		dt1.plusMinutes(12);
		dt1.plusSeconds(12);
		dt1.plusNanos(12);		
		
		
	} 
	

}
