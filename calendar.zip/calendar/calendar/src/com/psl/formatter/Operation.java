package com.psl.formatter;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class Operation {
	
	public static void main(String[] args) {

		LocalDate date1=LocalDate.of(1992, 2, 23);
		LocalTime time1=LocalTime.of(12,17,39,98);

		DateTimeFormatter d1=DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL);
		DateTimeFormatter d2=DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
		DateTimeFormatter d3=DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
		DateTimeFormatter d4=DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
		
		System.out.println(d1.format(date1));
		System.out.println(d2.format(date1));
		System.out.println(d3.format(date1));
		System.out.println(d4.format(date1));
		
		//only 2 format styles for time medium and short
		//DateTimeFormatter t1=DateTimeFormatter.ofLocalizedTime(FormatStyle.FULL);
		//DateTimeFormatter t2=DateTimeFormatter.ofLocalizedTime(FormatStyle.LONG);
		DateTimeFormatter t3=DateTimeFormatter.ofLocalizedTime(FormatStyle.MEDIUM);
		DateTimeFormatter t4=DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT);
		

		System.out.println(t3.format(time1));
		System.out.println(t4.format(time1));
		
		
		
		DateTimeFormatter p1=DateTimeFormatter.ofPattern("yyyyy"); //digit doesnt count
		//DateTimeFormatter p2=DateTimeFormatter.ofPattern("yy HH"); //date doesnt have hours
		DateTimeFormatter p3=DateTimeFormatter.ofPattern("yyy D");
		DateTimeFormatter p4=DateTimeFormatter.ofPattern("yy DD MM ");
		System.out.println(p1.format(date1));
		//System.out.println(p2.format(date1));
		System.out.println(p3.format(date1));
		System.out.println(p4.format(date1));

	
	}
	

}
