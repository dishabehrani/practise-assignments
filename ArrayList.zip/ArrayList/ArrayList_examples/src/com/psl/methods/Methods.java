package com.psl.methods;

import java.awt.List;
import java.lang.reflect.Array;
import java.util.ArrayList; // explicitly  added
import java.util.Iterator;
import java.util.ListIterator;


public class Methods {

	
	public static void main(String[] args) {
		
		
//		ArrayList<String> al=new ArrayList<>(); //valid after 1.7

		ArrayList<String> al=new ArrayList<String>();
		
		//al.add(101); //CE->of type string only 
		al.add("A");
		al.add("i");
		al.add("e");
		al.add(1,"u");
		
		
		//for each
		System.out.print("for each   :");
		for(String s :al){
			System.out.print(s+" ");
		}
		
		System.out.println();
		//iterator
		System.out.print("iterator  :");
		Iterator<String> itr=al.iterator();
		
		
		while(itr.hasNext()){
			System.out.print(itr.next()+" ");
		}
		
	
		System.out.println();
		
		//list iterator
		System.out.print("list iterator :");
		ListIterator<String > itr1=al.listIterator(); //type of iterator needs to be specific
		
		while(itr1.hasNext())
		{
			System.out.print(itr1.next());

	
		}
		System.out.println( "modified:");
		
		
		//modify
		al.set(1,"U");
		
		for(String s :al){
			System.out.print(s+" ");
		}
		
		
		
		//add to arraylist cannot by string therefore use String BUilder 
		
		ArrayList<StringBuilder> sb=new ArrayList<>();
		sb.add(new StringBuilder("Add"));
		sb.add(new StringBuilder("Subtract"));
		sb.add(new StringBuilder("Divide"));
		sb.add(new StringBuilder("Multiply"));
		
		System.out.println();
		for(StringBuilder s:sb)
			s.append(s.length());
		for(StringBuilder s:sb)
			System.out.println(s);
		
		
	//delete
		
		ArrayList<StringBuilder> sb1=new ArrayList<>();
		StringBuilder b1= new StringBuilder("add");
		StringBuilder b2= new StringBuilder("subtract");
		StringBuilder b3= new StringBuilder("multiply");
		StringBuilder b4= new StringBuilder("divide");
		
		sb1.add(b1);
		sb1.add(b2);
		sb1.add(b3);
		sb1.add(b4);
		
		
		System.out.println("before deletion------");
		
		for(StringBuilder s:sb1)
			System.out.println(s);
		System.out.println("after  position 1 removed");
		sb1.remove(1);
		for(StringBuilder s:sb1)
			System.out.println(s);

		System.out.println("after  object b3 removed");
		sb1.remove(b3);

		sb1.remove(new StringBuilder("divide"));//wont delete as equals is not overriden for StringBuilder
		for(StringBuilder s:sb1)
			//s.remove(1); //cannot remove element while travesring
			System.out.println(s);
		
	}
	
	
	
	
}
