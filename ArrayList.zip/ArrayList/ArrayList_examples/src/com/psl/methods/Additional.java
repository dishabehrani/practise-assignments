package com.psl.methods;

import java.util.ArrayList;

public class Additional {
	
	
	public static void main(String[] args) {
		
		String str1="one";
		String str2="two";
		str1=str1.replace('o', 'b');
		//str1.replace('o', 'b'); //doesnt replaces
		ArrayList<String> al=new  ArrayList<>();
		
		al.add(str1);
		al.add(str2);
		
		
		ArrayList<String>yl=new  ArrayList<>();
		
		yl.add("disha");
		yl.add("behrani");
		
		//at end
		System.out.println("at end:");
		yl.addAll(al);
		
		for(String a:yl)
			System.out.println(a);
		//at a specific position
		System.out.println("at specific :");
		str1=str1.replace('o', 'b');
		yl.addAll(1, al);
		//yl.addAll(7, al);//RE->AIOOBE
		for(String a:yl)
			System.out.println(a);
		
		
		
		
		
		System.out.println("cleared");
		yl.clear();
		for(String a:yl)
			System.out.println(a); //no op
		
		
		StringBuilder sb1= new StringBuilder("Jan");
		StringBuilder sb2= new StringBuilder("Feb");
		
		
		ArrayList<StringBuilder> a=new ArrayList<>();
		a.add(sb1);
		a.add(sb2);
		a.add(sb2);
		
		
		//it checks if it points to the same reference variable fro this we need to override equals()
		System.out.println(a.size());
		System.out.println(a.get(1));
		System.out.println(a.lastIndexOf(sb2));
		System.out.println(a.lastIndexOf(new StringBuilder("Feb")));
		System.out.println(a.indexOf(sb1));
		System.out.println(a.indexOf(new StringBuilder("Feb")));
		System.out.println(a.contains(sb2));
		System.out.println(a.contains(new StringBuilder("Feb")));
		
		

		//clone-shallow copy 
		//new instance of arraylist obj but elements refernces are copied

		System.out.println("cloned copy");
		
		ArrayList<StringBuilder> assigned=a;
		
		ArrayList<StringBuilder> cloned= (ArrayList<StringBuilder>)a.clone();
		
		
		System.out.println(a==assigned);
		System.out.println(a==cloned);
		System.out.println(assigned==cloned);
		
		
		
		
		StringBuilder a_var=a.get(0);
		StringBuilder assigned_var=assigned.get(0);	
		StringBuilder cloned_var=cloned.get(0);
		
		System.out.println(a_var==assigned_var);
		System.out.println(a_var==cloned_var);
		System.out.println(assigned_var==cloned_var);
		
		
		
		
		
	}

}
