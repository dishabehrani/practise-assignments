package com.psl.loops;

public class Loop_for {
	
	
	public static void main(String[] args) {
		
		
		
		for(int i=1;i<=3;i++)
		{
			System.out.println(i);
		}
		
		int i;
		for(i=1;i<10;i++)
		{
			System.out.println(i);
			
		}
		System.out.println("i is accessible:"+i);
	
		
		
		for(char a='a';a<'e';a++)
		{
			System.out.println(a);
			
		}	
		//System.out.println(a);//not accessible only inside for block
		
		
		//multiple declaration allowed but only of one type
//		for(int j=1,char a='a';i<10;i++,a++) //CE->delete token char 
		
		
		//int a=10 , long e =90; //invalid token ; expected
		//int a=10,int j=10; ////invalid token ; expected
		
		
		//for(int j=1,int a=2;i<10;i++,a++) //CE->delete token char
		
		
		
		for (int j=10,k=12;j<k;j++); //valid without body
		
		//for (int j=10,k=12;j<k;j++)  //CE->empty statemtent ecpected after ) 
		
		
		for (int j=10,k=12;j<k;j++){
			System.out.println(j+": "+k);
		}
		
		
		
	
		
		
		
		}
	
}
