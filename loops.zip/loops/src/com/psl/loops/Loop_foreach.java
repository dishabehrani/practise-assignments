package com.psl.loops;

import java.util.ArrayList;
import java.util.Iterator;

public class Loop_foreach {
	public static void main(String[] args) {
		
		
		ArrayList<String > al=new ArrayList<>();
		
		al.add("hi");
		al.add("hello");
		
		
		//to complex 
		for(Iterator<String>i=al.iterator();i.hasNext();){
			System.out.println(i.next());
			
		}
		
		
		//for each
		for(String s:al){
			System.out.println(s);
		}
		//nested for each
		ArrayList <String> subject =new ArrayList<>();
		subject.add("java ");
		subject.add("css ");
		
		ArrayList <String> level =new ArrayList<>();
		level.add("begginer");
		level.add("intermediate");
		level.add("advanced");
		
		ArrayList <String> grade =new ArrayList<>();
		grade.add("pass");
		grade.add("fail");
		
		ArrayList <ArrayList <String> > exam =new ArrayList<>();
		exam.add(subject);
		exam.add(level);
		exam.add(grade);
		
		
		for(ArrayList<String> e  :exam)
			for(String s:e)
				System.out.println(s);
		
		
		//when modified on primitive it doesnt modifiy the array elements
		int primenum[]={3,5,7,9,11};
	//	int total=0;
		for(int num:primenum){
			num+=1;
		
		
		}
		for(int num:primenum){
			System.out.println(num);
		
		
		}

		//when modified on collection it does modifiy the collection elements case1-		
		StringBuilder arr[]= {new StringBuilder("JAVA"),new StringBuilder("ORACLE")};
		
		for(StringBuilder s:arr)
			System.out.println(s);
	

		for(StringBuilder s:arr)
			s.append(" learn");
		
		for(StringBuilder s:arr)
			System.out.println(s);
		

		for(StringBuilder s:arr)
			System.out.println(s);
		 
			
		//when modified on collection it does modifiy the collection elements case2 - when assigned		
				StringBuilder arr1[]= {new StringBuilder("JAVA"),new StringBuilder("ORACLE")};
				
				for(StringBuilder s:arr1)
					System.out.println(s);
			

				for(StringBuilder s:arr1)
					s=new StringBuilder("c++");				
				for(StringBuilder s:arr1)
					System.out.println(s);
				

				for(StringBuilder s:arr1)
					System.out.println(s);
				 
					
		
		
	}

}
