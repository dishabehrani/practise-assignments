package com.psl.springLifecycle;

public class HappyFortune implements FortuneService {

	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
		return "Happy day !";
	}

}
