package com.psl.springLifecycle;

public interface FortuneService {
	
	public String getFortune();

}
