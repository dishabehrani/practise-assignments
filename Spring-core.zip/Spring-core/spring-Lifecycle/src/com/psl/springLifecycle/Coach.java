package com.psl.springLifecycle;

public interface Coach {

	public String getDailyWorkout();
	public String getFortune();
	
}
