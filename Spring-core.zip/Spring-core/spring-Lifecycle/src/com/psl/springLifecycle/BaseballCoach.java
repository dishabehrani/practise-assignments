package com.psl.springLifecycle;


public class BaseballCoach implements Coach {
	
	
	private FortuneService fortune;
	
	
	

	public BaseballCoach(FortuneService fortune) {
	
		this.fortune = fortune;
	}


	@Override
	public String getDailyWorkout() {
		return "batting practise";
	}


	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
		return fortune.getFortune();
	}
	
	
	//init method
	public void  doInit()
	{
		System.out.println("inside init method");
		
	}
	
	//destroy
	public void doDestroy()
	{
		System.out.println("inside destroy method");
	}
}
