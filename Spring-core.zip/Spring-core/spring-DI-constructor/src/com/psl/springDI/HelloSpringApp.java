package com.psl.springDI;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HelloSpringApp {

	public static void main(String[] args) {

		// loading  spring config file
		ClassPathXmlApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
				
		// retrieve bean from spring container
		Coach theCoach = context.getBean("myCoach", Coach.class);
		
		//  method calling  on the bean
		System.out.println(theCoach.getDailyWorkout());
		
		
		System.out.println(theCoach.getFortune());
		
		
		//  context closed
		context.close();
	}

}







