package com.psl.springDI;

public interface FortuneService {
	
	public String getFortune();

}
