package com.psl.springDI;


public class BaseballCoach implements Coach {
	
	
	private FortuneService fortune;
	
	
	

	public BaseballCoach(FortuneService fortune) {
	
		this.fortune = fortune;
	}


	@Override
	public String getDailyWorkout() {
		return "batting practise";
	}


	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
		return fortune.getFortune();
	}
	
	
}
