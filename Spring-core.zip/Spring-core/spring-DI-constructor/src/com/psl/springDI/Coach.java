package com.psl.springDI;

public interface Coach {

	public String getDailyWorkout();
	public String getFortune();
	
}
