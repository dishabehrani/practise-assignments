package com.psl.springIOC;

public interface Coach {
	public String getDailyWorkout();
}
