package com.psl.springIOC;

public class MyApp {

	public static void main(String[] args) {
		
		//hard coded we need to specify  its of type BaseballCoach
		Coach c=new BaseballCoach();
		System.out.println(c.getDailyWorkout());
		
		//again new object of type Track
		Coach c1=new TrackCoach();
		System.out.println(c1.getDailyWorkout());
	}
}
