package com.psl.springIOC;


public class BaseballCoach implements Coach {

	@Override
	public String getDailyWorkout() {
		return "batting practise";
	}
	
	
}
