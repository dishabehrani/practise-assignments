package com.psl.rest.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.psl.rest.entity.Student;

@RestController
@RequestMapping(value="/test",produces="MediaType.APPLICATION_JSON_VALUE")
public class DemoController {

	
	
	
	@GetMapping("/student")
	public List<Student> list()
	{
		List<Student> stud=new ArrayList<>();
		
		stud.add(new Student("disha", "behrani"));
		stud.add(new Student("aashi", "sharma"));
		stud.add(new Student("anushi", "agrawal"));
		
		return stud;
	}
}
