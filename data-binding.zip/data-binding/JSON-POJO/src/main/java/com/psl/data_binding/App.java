package com.psl.data_binding;

import java.io.File;
import java.io.IOException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	try {
			//create object mapper
			ObjectMapper mapper=new ObjectMapper();
			
			//read JSON file and convert to POJO
			Student theStudent=mapper.readValue(new File("data/sample-full.json"),Student.class);
			
			System.out.println(theStudent.getFirstName());
			System.out.println(theStudent.getLastName());
			
			Address add=theStudent.getAddress();
			
			System.out.println(add.getCity());
			System.out.println(add.getState());
			
			for(String lang:theStudent.getLanguages()){
				System.out.println(lang);
			}
			
    	} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
}
