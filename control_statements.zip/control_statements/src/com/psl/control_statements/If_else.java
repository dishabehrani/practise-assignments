package com.psl.control_statements;

public class If_else {
	
	public static void main(String[] args) {
		
		
		//if(true==false)//CE->statement is complusory after an if
		//if(true==false)//Ce->no assignment without curly brace
			//int i=10;
		
		
		if(10==10);;;;;;;
		
		
		int i=10;
		if((i=i+10)>=20)
			System.out.println(i); //modified value of i
			
		
		if(2==2)
			System.out.println("hi");
			
		
		/*cannot skip if block
		if(true == false)  //CE-> delete token else
		else
			System.out.println("hello");
		*/
		
		/*	cannot skip if		
		else        //CE-> delete token else
		System.out.println("hello");
		*/
		
		
		//case1->
		String name="disha";
	
		if(name.equals("disa"))
			name="behrani";
			System.out.println(name); //executes even if is false
			
			
			
		//case2->
//			String name1="disha";
//			
//			if(name1.equals("disa"))
//				name1="behrani";
//				System.out.println(name1);  //incase of else you can have only one statement after if in absense of{}
//				else
//					System.out.println("name1");
		
			//case3-->
			String name1="disha";
		
			if(name1.equals("disha"))
				{name1="behrani";
				System.out.println(name1); 
				}
			else
				System.out.println(name1); //part of else
				System.out.println("100 is score for "+name1); //not a part of else
		
			//case4-->
				
				if(name1.equals("dsha"))
				{name1="behrani";
				System.out.println(name1); 
				}
			else
			{
				System.out.println(name1); //part of else
				System.out.println("100 is score for "+name1); // a part of else
			}
				
				
			
			//case5-->
				String  str1="disha";
				String  str2="disha";
				
				if(str1.equals(str2))
					System.out.println("str"); //use equals() for objects
				
				if(true == true)
					System.out.println(str1); //use == for values (comparison)
				
				
				//case 6-->
//					String allow=false;   //CE->cannot convert boolean to string
//					if(allow=true)
//						System.out.println("executed");
				
				
				Boolean allow=false; //here its an assignment
				if(allow=true)
					System.out.println("executed");
//	
				
	
				/*here in java 1!=true 0!=false
				if(1) //cannnot convert int to boolean   
					System.out.println("hi");
					*/
				
				int sc=100;
				
			if(sc==10)
				System.out.println(100);
				System.out.println(200);
				if(sc==100)
					System.out.println(200);
				
				
				
				
				if(sc>1000)
					System.out.println(1000);
					System.out.println("not true");
					if(sc<=100)
						//System.out.println("true"); //not allowed
						if(sc==100)
							System.out.println(true );
						else
							System.out.println("finally false");

					else
							System.out.println("false");
	}
	
	

}
 