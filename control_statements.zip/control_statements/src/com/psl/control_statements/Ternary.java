package com.psl.control_statements;

public class Ternary {
	
		private static int bill=100;
	
	
	public static int m1()
	{
		return bill=bill-10;
	}
	
	public static int  m2()
	{
		return bill=bill-20;
	}
	public static void main(String[] args) {
		
		
		
		int discount=bill>10?10:20;
		System.out.println(discount);
		System.out.println(bill>10?10:20);
		
		//bill>10?10:20;  //ce->invalid assignemnt operator
		
		
		
		//{} [] not allowed
		//int discount1=bill>10?[10]:[20]; //CE->invalid
		
		//int discount1=bill>10?{bill-10}:{bill-20}; //CE->invalid
		
		
		// //but () are allowed perform expression
		int discount1=bill>10?(bill-10):(bill-20);
		System.out.println(discount1);
		

		//{} [] not allowed
		int discount2=(bill>10)?10:20;
		System.out.println(discount2);
		
		//also call methods
		int discount3=((bill<10)?(m1()):(m2())); //increases readability
		System.out.println(discount3);
		
		//first expression doesnt return a boolean
		//int discount1=bill++?(bill-10):(bill-20); //cannot convert int to boolean
	
		
		//int discount1=bill>10?:(bill-20); //CE->Expreesion missing after ?
		
		//int discount1=bill>10?(bill-10); //CE->insert ": exp " to complete expression
	
		
		int disc;
		Integer disc1;
		long bill=1200L;
		
		disc=bill<100?new Integer(10):new Integer(20); //wrapper ->primitive unboxing
		disc1=bill>100?10:90; //primitive to wrapper autoboxing
		
		
		System.out.println(disc);

		System.out.println(disc1);
		
		//disc=bill<100?bill-10:bill-20; //cannot convert from long to int
		
		
		//Long di=bill>100?1678872:134758273; //cannot convert from int to Long
	
		
			long di=bill>100?1678872:134758273; 
						System.out.println(di);	

			//Long dsc=bill<100?new Integer(10):new Integer(20); //cannot convert from Integer to Long
						
						

			int year=1997;
			int day=7;
			int month=7;
			
			
			String ans=(1997>2000)?"good":100>3?"gh":"bad";
			System.out.println(ans);
			
			int ans1=(year>2000)?1997:(month>8)?7:(day>7)?2:4;
		System.out.println(ans1);
		
						
		
	}

}
