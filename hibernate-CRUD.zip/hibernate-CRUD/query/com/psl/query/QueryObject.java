package com.psl.query;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import com.psl.model.Student;

public class QueryObject {
	
	public static void main(String[] args) {
		
		
		
		SessionFactory factory =new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Student.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		try
		{	//begin session
			session.beginTransaction();
			
			//retreive all students
			List<Student> all=session
							.createQuery("from Student")
							.list();
					
			
			
			
			//display the students
			System.out.println("all students");
			for(Student a:all)
				System.out.println(a);
			
			
			
			//where clause
			List<Student> name=session.createQuery("from Student s where "+ 
			" s.firstName='aashi'  OR  s.lastName='agrawal'").list(); //add space for next like
			
			
			//display the students where clause
			System.out.println("where clause students");
			for(Student a:name)
				System.out.println(a);
			
			
			
			
			//like clause -not case sensitive
			List<Student> like=session.createQuery("from Student s where "+ 
					" s.email LIKE '%gmail.com'").list(); //add space for next like
					
			//display the students like clause
			System.out.println("like clause students");
			for(Student a:like)
				System.out.println(a);
			
		
			//commit transaction
			session.getTransaction().commit();
		}
		
		finally{
			factory.close();
		}
		
								
	}

}
