package com.psl.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//Java Annotation
//Step 1-  map class to DB table
//Step 2-  map fields to DB column


@Entity   //represents a class is mapped to a database
@Table(name="student")   //if class and DB table has same name no need for this annotation
public class Student {
	

	@Id //represents a primary key of table
	@Column(name="id") //should match the exact  name of DB column
	private int id;    //if same as Db column no need for @Column annotation
	
	@Column(name="first_name")
	private String firstName;
	
	
	
	@Column(name="last_name")
	private String lastName;
	
	
	@Column(name="email")
	private String email;
	
	public int getId() {
		return id;
	}

	
	Student(){
		
	}
	

	public Student(String firstName, String lastName, String email) {
	
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
	}





	public void setId(int id) {
		this.id = id;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	@Override
	public String toString() {
		return "Student [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + "]";
	}


	
	
	
	

}
