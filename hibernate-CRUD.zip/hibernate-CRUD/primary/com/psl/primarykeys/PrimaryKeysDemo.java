package com.psl.primarykeys;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.model.Student;

public class PrimaryKeysDemo {

	public static void main(String[] args) {
		
		//create session factory
		
		SessionFactory factory=new Configuration()
									.configure("hibernate.cfg.xml")
									.addAnnotatedClass(Student.class)
									.buildSessionFactory();
		
		
		//create a session
		Session session=factory.getCurrentSession();
		
		try{
			
			//use session object to save the java object
			
			
			//create a student object
			System.out.println("creating 3 new student object");
			Student temp1=new Student("anushi","agrawal","anushi@gmail.com");
			Student temp2=new Student("aashi","sharma","aashi@gmail.com");
			Student temp3=new Student("divya","dalani","divya@gmail.com");
			
			
			//start a transaction
			session.beginTransaction();
			
			//save the student object
			System.out.println("saving the student");
			session.save(temp1);
			session.save(temp2);
			session.save(temp3);
			
			//commit transcation
			session.getTransaction().commit();
		}
		
		finally
		{
			factory.close();
		}
		

	}

}
