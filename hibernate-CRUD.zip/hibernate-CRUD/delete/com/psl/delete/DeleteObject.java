package com.psl.delete;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import com.psl.model.Student;

public class DeleteObject {
	
	public static void main(String[] args) {

		
		
		SessionFactory factory =new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Student.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		try
		{	//begin session
			session.beginTransaction();
		
			
			
		
			
		
			//alernate
			session.createQuery("delete from Student where id=4").executeUpdate();
			
			
			//commit transaction in DB
			session.getTransaction().commit();
			
		
		}
		
		finally{
			factory.close();
		}
		
								
	}

}
