package com.psl.update;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import com.psl.model.Student;

public class UpdateObject {
	
	public static void main(String[] args) {

		
		
		SessionFactory factory =new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Student.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		try
		{	//begin session
			session.beginTransaction();
		
			int  id=1;
			int id2=2;
			
			//retrieve student with id
			Student up=session.get(Student.class, id);
			//set the updated value in memory
			up.setFirstName("Anushi");
			up1.setFirstName("dusht");
			
			//update for all students
			
			session.createQuery("Update Student set email='foo@gmail.com'").executeUpdate();
			
			
			//commit transaction in DB
			session.getTransaction().commit();
			
		
		}
		
		finally{
			factory.close();
		}
		
								
	}

}
