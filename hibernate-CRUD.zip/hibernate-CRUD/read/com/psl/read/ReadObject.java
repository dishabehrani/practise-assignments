package com.psl.read;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import com.psl.model.Student;

public class ReadObject {
	
	public static void main(String[] args) {
		
		
		
		SessionFactory factory =new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Student.class)
								.buildSessionFactory();
		
		Session session=factory.getCurrentSession();
		
		try
		{	//create student object
			Student temp=new Student("abc","pqr","abc@GMAIL.COM");
			
			//begin session
			session.beginTransaction();

			//save the object 
			session.save(temp);	E
			
			//get the sudent's id :primary key
			System.out.println("saved students id is:" +temp.getId());
			
			
//			//now create a new session and start trancation
//			session=factory.getCurrentSession();
//			session.beginTransaction();
			
			
			//retrieve a student based on id:primary key
			System.out.println("geeting student with id"+temp.getId());
			
			Student readStudent=session.get(Student.class,temp.getId());
			
			System.out.println("complete student info="+readStudent);
				
			
			//commit transaction
			session.getTransaction().commit();
		}
		
		finally{
			factory.close();
		}
		
								
	}

}
