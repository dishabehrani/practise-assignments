package com.psl.security.spring;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.User.UserBuilder;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{

	protected void configure(AuthenticationManagerBuilder auth)throws Exception{
		//add users for in memory authentication
		
	UserBuilder user=User.withDefaultPasswordEncoder();
	
	auth.inMemoryAuthentication()
	.withUser(user.username("disha").password("123").roles("EMPLOYEE"))
	.withUser(user.username("aashi").password("123").roles("MANAGER","EMPLOYEE"))
	.withUser(user.username("anushi").password("123").roles("ADMIN","EMPLOYEE"))
	.withUser(user.username("divya").password("234").roles("ADMIN","MANAGER","EMPLOYEE"));
	
		
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
	
			http.authorizeRequests()
			.antMatchers("/").hasRole("EMPLOYEE")
			.antMatchers("/leaders/**").hasRole("MANAGER")
			.antMatchers("/system/**").hasRole("ADMIN")
			.and()
			.formLogin()
			.loginPage("/show")
			.loginProcessingUrl("/authenticateTheUser") //in built
			.permitAll()
			.and()
			.logout()
			.permitAll()
			.and()
			.exceptionHandling()
			.accessDeniedPage("/access-denied");
	
	}
	
	
	
}
