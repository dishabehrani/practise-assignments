package com.psl.security.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DemoController {

	
	@RequestMapping("/")
	public String home(){
		return "home";
	}

	@RequestMapping("/leaders")
	public String leader(){
		return "leader";
	}
	
	@RequestMapping("/system")
	public String system(){
		return "system";
	}

	
	
}
