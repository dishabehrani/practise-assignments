package com.psl.security.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {

	
	@RequestMapping("/show")
	public String home(){
		return "fancy-login";
	}
	
	@RequestMapping("/access-denied")
	public String denied(){
		return "deny";
	}

}
