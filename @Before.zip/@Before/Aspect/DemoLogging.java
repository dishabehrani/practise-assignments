package com.psl.aop.Aspect;


import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class  DemoLogging{
	
	// Advice type--> @Before 
	//execute it before method name  -->add in AccountDAO.class
	@Before("execution(public void add())")
	public void beforeAddAccountAdvice() {
		
		System.out.println("\n=====>>> Executing @Before advice on add()");
		
	}
}