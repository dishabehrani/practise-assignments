package com.psl.aop;

import org.springframework.stereotype.Component;

@Component
public class AccountDAO {

	
	public void add(){
		System.out.println("adding an account");
	}
}
