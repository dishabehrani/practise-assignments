package com.psl.aop;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp {
	public static void main(String[] args) {
		
	//read spring config java class
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(DemoConfig.class);
		
	//get the bean from spring container
		AccountDAO acc=context.getBean("accountDAO",AccountDAO.class);
		
	//call the business method
		acc.add();
		
	//close context
		context.close();
		
		
	}

}
