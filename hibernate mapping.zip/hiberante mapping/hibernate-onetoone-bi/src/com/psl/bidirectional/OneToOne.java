package com.psl.bidirectional;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.entity.Instructor;
import com.psl.entity.InstructorDetail;

public class  OneToOne{

	public static void main(String[] args) {

		// create session factory
		SessionFactory factory = new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Instructor.class)
								.addAnnotatedClass(InstructorDetail.class)
								.buildSessionFactory();
		
		// create session
		Session session = factory.getCurrentSession();
		
		try {			
			
			// start a transaction
			session.beginTransaction();

			// getting  the instructor detail object
			//returns null if not found
			int theId = 2;
			InstructorDetail tempInstructorDetail = 
					session.get(InstructorDetail.class, theId);
						
			// printing  the  instructor
			System.out.println("the associated instructor: " + 
								tempInstructorDetail.getInstructor());
			
			// commit transaction
			session.getTransaction().commit();
		}
		//if NPE 
		catch (Exception exc) {
			exc.printStackTrace();
		}
		finally {
			
			
			//cleans up connection pool
			session.close();
			
			factory.close();
		}
	}

}





