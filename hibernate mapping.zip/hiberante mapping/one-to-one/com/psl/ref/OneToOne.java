package com.psl.ref;




import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.entity.Instructor;
import com.psl.entity.InstructorDetail;

public class OneToOne {

	public static void main(String[] args) {

		// create session factory
		SessionFactory factory = new Configuration()
								.configure("hibernate.cfg.xml")
								.addAnnotatedClass(Instructor.class)
								.addAnnotatedClass(InstructorDetail.class)
								.buildSessionFactory();
		
		// create session
		Session session = factory.getCurrentSession();
		
		try {			
			
			// create the objects
			
			Instructor temp1 = 
					new Instructor("abc", "pqr", "abc@gmail.com");
			
			InstructorDetail tempInstructorDetail1 =
					new InstructorDetail(
							"http://www.abc.com/youtube",
							"code!!!");		
			
			
			Instructor temp2 = 
					new Instructor("sdf", "jhk", "sdf@gmail.com");
			
			InstructorDetail tempInstructorDetail2 =
					new InstructorDetail(
							"http://www.youtube.com",
							"dance");		
			
			// associate the objects
			temp1.setInstructorDetail(tempInstructorDetail1);
			temp2.setInstructorDetail(tempInstructorDetail2);
			
			// start a transaction
			session.beginTransaction();
			
			// save the instructor
			//
			//  also  saves the details object cos of cascadeType is ALL
			
		
			// commit transaction
			session.getTransaction().commit();
			
		}
		finally {
			factory.close();
		}
	}

}





