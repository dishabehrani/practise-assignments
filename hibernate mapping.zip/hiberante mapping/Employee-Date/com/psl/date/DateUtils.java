package com.psl.date;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

	
	
	private static SimpleDateFormat formatter=new SimpleDateFormat("dd/mm/yyyy");
	
	
	public static Date parseDate(String dateStr) throws ParseException
	{
		Date d =formatter.parse(dateStr);
		return d;
	}
	
	
	public static String formatDate(Date d){
		
		
		
		String s=formatter.format(d);
		
		return s;
	}
}
