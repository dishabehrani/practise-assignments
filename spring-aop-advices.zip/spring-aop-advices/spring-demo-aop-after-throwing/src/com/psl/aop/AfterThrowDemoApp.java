package com.psl.aop;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.psl.aop.dao.Account;
import com.psl.aop.dao.AccountDAO;
import com.psl.aop.dao.MembershipDAO;

public class AfterThrowDemoApp {
	
	public static void main(String[] args) {
		
		
		
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext(DemoCongif.class);
		
		AccountDAO account= context.getBean("accountDAO",AccountDAO.class);
		
		List<Account> list=null;
		//Call method findAccount()
		try
		{
			boolean tripwire=true;
		 list=account.findAccount(tripwire);
		}
		catch(Exception exc){
			System.out.println("Exception  caught in main app"+exc);
		}
		//display the account
		System.out.println("main app after :AfterThrowing");
		System.out.println(list);
		
		
		
		
		context.close();
	}

}
