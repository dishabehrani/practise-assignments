package com.psl.aop;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.psl.aop.dao.Account;
import com.psl.aop.dao.AccountDAO;
import com.psl.aop.dao.MembershipDAO;

public class AfterReturnDemoApp {
	
	public static void main(String[] args) {
		
		
		
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext(DemoCongif.class);
		
		AccountDAO account= context.getBean("accountDAO",AccountDAO.class);
		
		//Call method findAccount()
		//on modifying the data in @AfterReturning the caller gets modified data 
		List<Account> list=account.findAccount();
		
		//display the account
		System.out.println("main app after :AfterReturning");
		System.out.println(list);
		
		
		
		
		context.close();
	}

}
