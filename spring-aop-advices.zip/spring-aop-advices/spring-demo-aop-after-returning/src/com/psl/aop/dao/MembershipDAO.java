package com.psl.aop.dao;

import org.springframework.stereotype.Component;

@Component
public class MembershipDAO {
	
	public void Sleeping(int id)
	{
		System.out.println(getClass()+ " sleep method ");
	} 

}
