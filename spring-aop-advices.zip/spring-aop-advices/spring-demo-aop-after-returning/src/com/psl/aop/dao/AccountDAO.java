package com.psl.aop.dao;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class AccountDAO {
	
	
	private String name;
	private int id;
	
	
	
	
	public String getName() {
		System.out.println("in getName()");
		return name;
	}




	public void setName(String name) {

		System.out.println("in setName()");
		this.name = name;
	}




	public int getId() {

		System.out.println("in getId()");
		return id;
	}




	public void setId(int id) {

		System.out.println("in setId()");
		this.id = id;
	}




	public void add(Account acc,boolean flag){
		System.out.println(getClass()+ " adding account to Account Dao");
	}
	
	public List<Account> findAccount(){
		
	List<Account>	 list=new  ArrayList<Account>();
	
	System.out.println("In method find account");
	Account a1=new Account(1,"gold");
	Account a2=new Account(2,"silver");
	Account a3=new Account(3,"platinum");
	
	list.add(a1); 	list.add(a2);	list.add(a3);

	return list;
	}
	

}
