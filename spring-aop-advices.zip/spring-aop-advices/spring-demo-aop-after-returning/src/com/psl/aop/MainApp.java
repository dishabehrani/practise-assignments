package com.psl.aop;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.psl.aop.dao.Account;
import com.psl.aop.dao.AccountDAO;
import com.psl.aop.dao.MembershipDAO;

public class MainApp {
	
	public static void main(String[] args) {
		
		
		
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext(DemoCongif.class);
		
		AccountDAO account= context.getBean("accountDAO",AccountDAO.class);
		
		MembershipDAO member= context.getBean("membershipDAO",MembershipDAO.class);
		
		Account acc=new Account(101,"manager");
		
		account.add(acc,true);
		//call getter 
		String name=account.getName();
		int id=account.getId();
		
		
		//call setter
		account.setId(1);
		account.setName("disha");
		member.Sleeping(101);
		
		context.close();
	}

}
