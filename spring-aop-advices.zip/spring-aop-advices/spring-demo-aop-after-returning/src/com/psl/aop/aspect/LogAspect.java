package com.psl.aop.aspect;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.psl.aop.dao.Account;

@Aspect
@Component
@Order(-209)
public class LogAspect {

	@Before("com.psl.aop.aspect.PointcutExp.combo()")
	private void  beforelog(JoinPoint theJointPoint){
		

		System.out.println("--->execute before logging");
		
		
		//display the method signature
		MethodSignature signature=(MethodSignature) theJointPoint.getSignature();
		System.out.println(signature);
		
		
		
		//display method arguments
		Object arg[]=theJointPoint.getArgs();
		
		for(Object tempArg:arg){
			System.out.println(tempArg);
			
			if(tempArg instanceof Account){
				
				
				Account  theAccount =(Account)tempArg;
				System.out.println("level="+theAccount.getLevel());
				System.out.println("id="+theAccount.getId());
				
				
			}
		}
	}

	
	
	@AfterReturning(pointcut="execution(* com.psl.aop.dao.AccountDAO.findAccount(..))",
					returning="result")
	public void afterReturningFindAcc(JoinPoint thejoinpoint,List<Account> result){
		
		//print method we are advicing
		String method=thejoinpoint.getSignature().toShortString();
		System.out.println("--->method signature @AfterReturning"+method);
		
		//post process the data ,give a modified value to the caller methods
		if(result!=null){
		
			Account acc=result.get(0);
				acc.setId(101);
		}
			covertToUpper(result);
		
		//print out results that are returned by the method called
		System.out.println("--->result from @AfterReturning"+result);
	}



	private void covertToUpper(List<Account> result) {
		
		for(Account temp :result){
			
			
			temp.setLevel(temp.getLevel().toUpperCase());
		}
	}
}
