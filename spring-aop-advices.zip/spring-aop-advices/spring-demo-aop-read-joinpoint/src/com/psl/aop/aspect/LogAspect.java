package com.psl.aop.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.psl.aop.dao.Account;

@Aspect
@Component
@Order(-209)
public class LogAspect {

	@Before("com.psl.aop.aspect.PointcutExp.combo()")
	private void  beforelog(JoinPoint theJointPoint){
		

		System.out.println("--->execute before logging");
		
		
		//display the method signature
		MethodSignature signature=(MethodSignature) theJointPoint.getSignature();
		System.out.println(signature);
		
		
		
		//display method arguments
		Object arg[]=theJointPoint.getArgs();
		
		for(Object tempArg:arg){
			System.out.println(tempArg);
			
			if(tempArg instanceof Account){
				
				
				Account  theAccount =(Account)tempArg;
				System.out.println("level="+theAccount.getLevel());
				System.out.println("id="+theAccount.getId());
				
				
			}
		}
	}

}
