package com.psl.spring1;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@org.springframework.stereotype.Controller
public class Controller {
	
	

	@RequestMapping("/")
	public String show(Model model)
	{
		Student student =new Student();
		
		
		model.addAttribute("student",student);
		return "show";
	}
	
	@RequestMapping("/process")
	public String show(@ModelAttribute("student") Student student)
	{
		return "process";
	}
}
