package com.psl.spring1;

import java.util.LinkedHashMap;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Student {
	
	@NotNull(message="cannot be null")
	@Size(min=1,message="more than 1 in size")
	private String firstName;
	private String lastName;
	private String country;
	
	private LinkedHashMap<String, String> options;
	
	private String gender;
	private String[] os;
	
	
	@Min(value=0,message="greater than 0")
	@Max(value=10,message="lesser than 10")
	private int passes;
	

	//pattern regular expression
	@Pattern(regexp="^[a=zA-Z0-9]{5}",message="only of 5 char/digit")
	private String postal;
	
	
	
	
	
	public int getPasses() {
		return passes;
	}

	public void setPasses(int passes) {
		this.passes = passes;
	}

	public String getPostal() {
		return postal;
	}

	public void setPostal(String postal) {
		this.postal = postal;
	}
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String[] getOs() {
		return os;
	}

	public void setOs(String[] os) {
		this.os = os;
	}

	Student(){
		options=new LinkedHashMap<>();
		options.put("india", "IN");
		options.put("Usa", "US");
		
			
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public LinkedHashMap<String, String> getOptions() {
		return options;
	}

	public void setOptions(LinkedHashMap<String, String> options) {
		this.options = options;
	}
	
	
	
}

