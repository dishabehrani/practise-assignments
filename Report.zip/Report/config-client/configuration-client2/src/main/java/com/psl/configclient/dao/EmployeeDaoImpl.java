package com.psl.configclient.dao;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.psl.configclient.config.entity.Report;
@Repository
public class EmployeeDaoImpl  implements EmployeeDao{
	
	
	@Autowired
	private JdbcTemplate jdbc;


	@Override
	public 	List<String> reportGenerator(Report theReport) {
		 
		List<String> list=new ArrayList<>();
		
		
		String query=theReport.getQuery();
		String table=theReport.getTable();
		List<String>columns=theReport.getColumns();
		
		
	
	
		
	  	
	  	
	  	System.out.println(query + " "+ table+" "+columns );
	  	
	  	
	  	
		return list;
	}
	
	
	
	
}