package com.psl.configclient.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowCallbackHandler;

public class RowMapper implements RowCallbackHandler {

	@Override
	public void processRow(ResultSet arg0) throws SQLException {
		// TODO Auto-generated method stub

	}

}
