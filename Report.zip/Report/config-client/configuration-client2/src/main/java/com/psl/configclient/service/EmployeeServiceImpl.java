package com.psl.configclient.service;

import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.psl.configclient.config.entity.Employee;
import com.psl.configclient.config.entity.Report;
import com.psl.configclient.dao.EmployeeDao;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	
	

	@Autowired
	private EmployeeDao dao;
	
	
	


	@Override
	public List<String> reportGenerator(Report theReport) {
	
		return dao.reportGenerator(theReport);
		}


	
}
	