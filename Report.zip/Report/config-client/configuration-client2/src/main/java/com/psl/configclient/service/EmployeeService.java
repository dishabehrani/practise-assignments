package com.psl.configclient.service;

import java.util.List;
import java.util.Map;

import com.psl.configclient.config.entity.Employee;
import com.psl.configclient.config.entity.Report;

public interface EmployeeService {
	
	

	public List<String> reportGenerator(Report theReport);
	
}
