package com.psl.configclient.config.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Employee {

	private int id;
	
	public String firstName;
	
	public String lastName;
	

	public String email;
	
	
	 public Employee(){}
	 
	@Override
	public String toString() {
		return "Employee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email + "]";
	}
	 
	
	
	 
	 
	 
}
