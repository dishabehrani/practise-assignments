package com.psl.configclient.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.psl.configclient.config.entity.Report;
import com.psl.configclient.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	
	@Autowired 
	private EmployeeService service;
	

	
	public EmployeeController(EmployeeService theservice) {
		service=theservice;
	}
	
	
	
	
	
	@RequestMapping("/test")
	public String  hello()
	{
		return "hello";
		
	}
	
	
	
	
	
	@PostMapping("/report")
	public List<String> generate(@RequestBody Report theReport)
	{
		
		return service.reportGenerator(theReport);
	}
	

	
	
}