package com.psl.aop.aspect;


import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class PointcutExp {

	
	@Pointcut("execution(* com.psl.aop.dao.*.*(..))")
	public void forAllInDAO(){
		
	}
	
	
	//for any class in package  method that starts with get
	@Pointcut("execution (* com.psl.aop.dao.*.get*(..))")
	public void forGetters(){
		
	}
	
	

	//for any class in package  method that starts with set
	@Pointcut("execution(* com.psl.aop.dao.*.set*(..))")
	public void forSetters(){
		
	}
	
	//for all methods excluding getter and setter
	@Pointcut("forAllInDAO() && !(forGetters() || forSetters())")
	public void combo(){

	}
}