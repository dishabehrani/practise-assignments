package com.psl.aop.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Order(-209)
public class LogAspect {

	@Before("com.psl.aop.aspect.PointcutExp.combo()")
	private void  beforelog(){
		
		System.out.println("--->execute before logging");
	}

}
