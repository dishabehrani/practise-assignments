package com.psl.aop.dao;

import org.springframework.stereotype.Component;

@Component
public class AccountDAO {
	
	public void add(){
		System.out.println(getClass()+ " adding account to Account Dao");
	}

}
