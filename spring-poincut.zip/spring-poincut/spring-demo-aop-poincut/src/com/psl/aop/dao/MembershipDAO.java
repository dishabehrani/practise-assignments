package com.psl.aop.dao;

import org.springframework.stereotype.Component;

@Component
public class MembershipDAO {
	
	public void Sleeping()
	{
		System.out.println(getClass()+ " sleep method ");
	} 

}
