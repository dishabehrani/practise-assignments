package com.psl.aop;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.psl.aop.dao.AccountDAO;
import com.psl.aop.dao.MembershipDAO;

public class MainApp {
	
	public static void main(String[] args) {
		
		
		
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext(DemoCongif.class);
		
		AccountDAO account= context.getBean("accountDAO",AccountDAO.class);
		
		MembershipDAO member= context.getBean("membershipDAO",MembershipDAO.class);
		
		
		account.add();
		member.Sleeping();
		
		context.close();
	}

}
