package com.psl.aop.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AspectConfig {

	
	
	@Pointcut("execution(* com.psl.aop.dao.*.*(..))")
	private  void pointcutDef(){
		
	}
	
	//both will execute before the methods 
	
	@Before("pointcutDef()")
	public void beforeAdd(){
		System.out.println("----->before ADD accounts");
	}
	
	@Before("pointcutDef()")
	public void beforeSleep(){
		System.out.println("-->before SLEEP methods");
	}
	
}
