package com.psl.aop.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class AspectConfig {

//	
//works for all methods in dao pacakge even for getter and setter  	
//	@Pointcut("execution(* com.psl.aop.dao.*.*(..))")
//	private  void pointcutDef(){
//		
//	}
//	
//	
//	@Before("pointcutDef()")
//	public void beforeAdd(){
//		System.out.println("----->before ADD accounts");
//	}
//	
//	@Before("pointcutDef()")
//	public void beforeSleep(){
//		System.out.println("-->before SLEEP methods");
//	}
	
	
	
	
	//execute on for methods in dao pacakage except the getter and setter
	
	//for any class any method in package
	@Pointcut("execution(* com.psl.aop.dao.*.*(..))")
	private void forAllInDAO(){
		
	}
	
	
	//for any class in package  method that starts with get
	@Pointcut("execution (* com.psl.aop.dao.*.get*(..))")
	private void forGetters(){
		
	}
	
	

	//for any class in package  method that starts with set
	@Pointcut("execution(* com.psl.aop.dao.*.set*(..))")
	private void forSetters(){
		
	}
	
	//for all methods excluding getter and setter
	@Pointcut("forAllInDAO() && !(forGetters() || forSetters())")
	private void combo(){
		
		
	}
	
	
	@Before("combo()")
	private void  beforeADD(){
		
		System.out.println("--->execute before adding");
	}
	
	@Before("combo()")
	private void  beforesleep(){
		
		System.out.println("--->execute before sleeping");
	}
}
