package com.psl.CRUDdemo.service;

import java.util.List;

import com.psl.CRUDdemo.entity.Employee;

public interface EmployeeService {


	public List<Employee> findAll();
	public Employee getEmployee(int id);
	public Employee save(Employee e);
	public  void delete(Employee e);
	
}
