package com.psl.CRUDdemo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.psl.CRUDdemo.entity.Employee;

@Transactional
@Repository
public class EmployeeDaoImpl  implements EmployeeDao{

	
	//define entity manager
	//automatically created by spring boot
	private EntityManager manager;
	
	
	//setup constructor injection

	public EmployeeDaoImpl(EntityManager themanager) {
		
		manager = themanager;
	}

	
	@Override
	public List<Employee> findAll() {
		
		Session session=manager.unwrap(Session.class);
		
		Query<Employee> query=session.createQuery("from Employee",Employee.class);
		
		
		List<Employee> list=query.getResultList();
		return list;
	}


	

	@Override
	public Employee getEmployee(int id) {
		Session session=manager.unwrap(Session.class);
		
		Employee emp=session.get(Employee.class, id);
		
		return emp;
		}



	@Override
	public Employee save(Employee e) {
		
		Session session=manager.unwrap(Session.class);
		session.saveOrUpdate(e);
		return e;
	}

	@Override
	public void delete(Employee e) {
		
		Session session=manager.unwrap(Session.class);
	
		session.delete(e);
		
	}



}
