package com.psl.CRUDdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.psl.CRUDdemo.entity.Employee;
import com.psl.CRUDdemo.service.EmployeeService;


@RestController
@RequestMapping("/api")
public class EmployeeController {

	
	@Autowired 
	private EmployeeService service;
	
	public EmployeeController(EmployeeService theservice) {
		service=theservice;
	}
	
	@GetMapping("/emp")
	public List<Employee> getEmployees()
	{
		List<Employee>list =service.findAll();
		return list;
	}

	@GetMapping("/empl")
	public String Employees()
	{
		return "hell";
	}

	@GetMapping("/emp/{empid}")
	public Employee getEmp(@PathVariable int empid)
	{
		
		
		return service.getEmployee(empid);
	}
	
	@DeleteMapping("/emp/{empid}")
	public String delete(@PathVariable int empid)
	{
		Employee e=	service.getEmployee(empid);
		
		service.delete(e);
		
		return "delete emp:"+empid;
		
	}

}
