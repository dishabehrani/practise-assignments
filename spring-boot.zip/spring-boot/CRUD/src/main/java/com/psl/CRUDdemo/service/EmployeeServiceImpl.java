package com.psl.CRUDdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.psl.CRUDdemo.dao.EmployeeDao;
import com.psl.CRUDdemo.entity.Employee;

@Service
public class EmployeeServiceImpl  implements EmployeeService{

	
	
	@Autowired
	private EmployeeDao dao;
	
	
	
	public EmployeeServiceImpl(EmployeeDao thedao) {
		
		dao = thedao;
	}

	@Transactional
	@Override
	public List<Employee> findAll() {
		return dao.findAll();
	}

	@Transactional
	@Override
	public Employee getEmployee(int id) {
		return dao.getEmployee(id);
	}
	@Transactional
	@Override
	public Employee save(Employee e) {
	return dao.save(e);
	
	}

	@Transactional
	@Override
	public void delete(Employee e) {
			dao.delete(e);
	}

}
