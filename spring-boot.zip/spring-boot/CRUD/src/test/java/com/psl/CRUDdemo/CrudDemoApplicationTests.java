package com.psl.CRUDdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
