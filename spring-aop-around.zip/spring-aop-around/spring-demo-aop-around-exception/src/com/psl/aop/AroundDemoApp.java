package com.psl.aop;


import java.util.logging.Logger;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.psl.aop.aspect.LogAspect;
import com.psl.aop.dao.FortuneService;

public class AroundDemoApp {
	
	private static Logger myLog=Logger.getLogger(AroundDemoApp.class.getName());
	
	public static void main(String[] args) {
		
		
		
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext(DemoCongif.class);
		
		FortuneService service= context.getBean("fortuneService",FortuneService.class);
		
		
		myLog.info("main app demo");
		myLog.info("calling the get fortune");
		
		//will never know an exception had occured
		boolean tripwire=true;
		String data=service.getFortune(tripwire);
		
		myLog.info("from main app my fortune for today is-->"+data);
		myLog.info("finished");
		context.close();
	}

}
