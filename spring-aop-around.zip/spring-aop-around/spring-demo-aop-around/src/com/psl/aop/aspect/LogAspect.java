package com.psl.aop.aspect;

import java.util.logging.Logger;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.psl.aop.AroundDemoApp;


@Aspect
@Component
@Order(-209)
public class LogAspect {
	private  Logger myLog=Logger.getLogger(LogAspect.class.getName());
	
	
	@Around("execution(* com.psl.aop.dao.*.*(..))")
	public Object aroundGetFortune(ProceedingJoinPoint pjp) throws Throwable
	{
		//print method 
		String method =pjp.getSignature().toShortString();
		myLog.info("--->Excectuing @Around method-->"+method);
		
		
		//begin ts	
		long begin=System.currentTimeMillis();
	
		//execute method
		Object result=pjp.proceed();
		
		
		//end ts	
		long end=System.currentTimeMillis();
			
		long d=end-begin;
		myLog.info("duration -->"+(d/1000)+"in seconds");
		
		
		
		
		return result;
		
	}
	
}
