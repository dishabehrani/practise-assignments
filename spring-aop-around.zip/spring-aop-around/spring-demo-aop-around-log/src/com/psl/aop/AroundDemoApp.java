package com.psl.aop;


import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.psl.aop.dao.FortuneService;

public class AroundDemoApp {
	
	public static void main(String[] args) {
		
		
		
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext(DemoCongif.class);
		
		FortuneService service= context.getBean("fortuneService",FortuneService.class);
		
		
		System.out.println("main app demo");
		System.out.println("calling the get fortune");
		
		String data=service.getFortune();
		
		System.out.println("from main app my fortune for today is-->"+data);
		System.out.println("finished");
		context.close();
	}

}
