package com.psl.overriding;



//case 1-->private 
//pratically the private methods are available only to that class  ,its not overriding its calling your own method
//parent method can't be private at all
//so you cant make a child as priavte also as you can't reduce visibility
/*class P{
	private void m1(){
		
	}
}

class C extends P{

	private void m1(){
		
	}
}*/

//case 2-->final
//P==FINAL C==NON-FINAL
//if we keep P () as final we can't override it in c()
//CE-->cannot override the final method from p
/*
class P{
	public final void m1(){
		
	}
}

class C extends P{

	public void m1(){
		
	}
*/

//case-->3 
//P==NON  FINAL  C==FINAL is possible no CE
class P{
	public void m1(){
		
	}
}
class C extends P{

	public final void m1(){
		
	}
}

//case-->4
//if  P class has abstract methods the P class should be made abstarct
//and compulsory the C should provide it s implementation or else gives CE
abstract class P3{
	abstract public void m1();
}
class C3 extends P3{

	
	public void m1() {
		System.out.println("abstarct of child");
	}


}

//case -->5 
//we can make P class as non abstract and C class as abstarct
//but we then need to make a sub class for C class that provides it implementation
 class P4{
	 public void m1(){
		 
	 }
}
abstract class C4 extends P4{

	
	public abstract void m1(); 


}

class C41 extends C4{
 public void m1(){
		 System.out.println("sub -child of child class ");
	 }
}

public class Modifiers {
	
public static void main(String[] args) {
	
	//P1 p=new P1(); //cannot instantiate abstract class
	
	C3 c=new C3();
	c.m1();
	P3 p=new C3(); //can use as at runtime we will get child class
	p.m1();
	
	
	P4 p1=new C41();
	p1.m1();
	
	 
}	
	
	
}
