package com.psl.overriding;

//After 1.4  covariant return types are allowed  but the parent should always retrun parent class object
//while child can return child type obj or parent 
//not applicable for primitives 

//case 1->P==OBJECT  C==STRING/Stringbuffer/string builder
class P7{
	
	public 	Object m1(){
		
		return null;
		}
}
class C7 extends P7 {
	public String m1(){
	 return null;
	 
	}
	
}


//case 2-> P==String C==OBJECT reverse is not applicable
// CE->incompatible types 
/*class P1{
	
	public 	String m1(){
		
		return null;
		}
}
class C1 extends P1 {
	public Object m1(){
	 return null;
	 
	}
	
}*/


//case 3->P==NUMBER C== FLOAT(wrapper) OR DOUBLE(wrapper) but not primitive classes
//reverse not allowed
class P1{
	
	public 	Number m1(){
		
		return null;
		}
}
class C1 extends P1 {
	public Double m1(){
	 return 10.5;
	 
	}
	
}


//case 4->  P==Object C= practically any object class wrapper string ,string buffer string builder but not with primitives
class P2{
	
	public 	Object m1(){
		
		return null;
		}
}
class C2 extends P2 {
	public Double m1(){
	 return null; //valid return 
	 
	}
	
}


//case 5 ->P==primtive  C==primtive  not allowed no promoting datatypes 
//CE->return type is incompatible
/*class P4{
	
	public 	double m1(){
		
		return 10.9;
		}
}
class C4 extends P4 {
	public int m1(){
	 return 12;
	 
	}
	
}*/



