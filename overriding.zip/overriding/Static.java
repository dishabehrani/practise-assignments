package com.psl.overriding;



//case1 we cant make p==static and child as non -static
//CE->instance method cant override static method
/*

class C {
	public static void m1(){
		
	}
	
}
class P extends C{
	
	public void m1(){
		
	} 
}
*/


//we cant make C ==STATIC and P==non static 
//CE->static method cannot hide instance method from c

/*
  class C {
 
	public  void m1(){
		
	}
	
}
class P extends C{
	
	public static void m1(){
		
	} 
}
*/



//we can make not methods as static
//that is not overriding but  method hiding
//it is complie time polymorphism
class Pi1 {
	 
	public  static void m1(){
		System.out.println("parent");
		
	}
	
}
class Ci1 extends Pi1
{
	
	public static void m1(){
		
		System.out.println("child");
	} 
}


public class Static {

	
	public static void main(String[] args) {
		
		 //parent
		//Pi1 p1=new Pi1();
		Pi1.m1();
		
		
		//Ci1 c1=new Ci1();
		Ci1.m1(); //child
		
		
		
		Pi1 p=new Ci1();
		p.m1(); //parent //object ref at complie time
		
		}
	
}
