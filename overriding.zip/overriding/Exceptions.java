package com.psl.overriding;

import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.IOException;

//p==exception c==nothing
class C
{
	public void m1() throws Exception{
		
	}
}

class P extends C{
	public void m1(){
		
	}
}


//if c has checked exception we need to throw exception of parent with higher exception or same level
//p==throwable /exception  c== exception

class C1

{
	public void m1() throws Throwable {
		
	}
}

class P1 extends C1{
	public void m1()throws Exception{
		
	}
}

//parent should throw higher or same level but its throwing a lower level exception
//Ce-->not compatible
/*
class C2

{
	public void m1() throws IoException {
		
	}
}

class P2 extends C2{
	public void m1()throws Exception{
		
	}
}

*/

class C2

{
	public void m1() throws Throwable {
		
	}
}

class P2 extends C2{
	public void m1()throws IOException,FileNotFoundException{
		
	}
}

//we have higher exception for file and and eof but for interrupted we dont have higher exception class to catch
/*class C3

{
	public void m1() throws IOException {
		
	}
}

class P3 extends C3{
	public void m1()throws FileNotFoundException,EOFException,InterruptedException{
		
	}
}*/


//no need to throw any exception in case of unchecked exception in child
class C5

{
	public void m1() {
		
	}
}

class P5 extends C5{
	public void m1()throws RuntimeException{
		
	}
}

public class Exceptions {

}
