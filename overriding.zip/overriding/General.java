package com.psl.overriding;





 class Parent{
	 public void m1(){
		 System.out.println("parent -invdi");
	 }
	public void m2(){
		System.out.println("common method -parent");
	}
}
 class Child extends Parent{
	 
	 public void m2(){
			System.out.println("common method -child");
		}
	
}

public class General {
	
	public static void main(String[] args) {
		
		//case 1--> pure parent method
		Parent p=new Parent();
		p.m1();
		p.m2();
		
		//case 2  --> if child has overridden it will provide its method ,if not parent
		Child c=new Child();
		c.m1();
		c.m2();
		
		
		//case 3  -->JVM during method resolution always consider methods given  at run time 
		Parent p1=new Child(); 
		p1.m1();
		p1.m2();
		
		
	}

}
