package com.psl.overriding;

//method visibility
//we cannot reduce the visibility from parent to child
//visibility of child should be more m

//if P==PUBLIC  C==public 
class P{
	
	public void m1(){
		
	}
	
}
class C extends P{
	
	public void m1(){
		
	}
	
}


//if p==protected  C== protected or public
class P1{
	
	protected void m1(){
		
	}
	
}
class C1 extends P1{
	
	public void m1(){
		
	}
	
}

//if p==default c=== public ,protected ,default
class P2{
	
	 void m1(){
		
	}
	
}
class C2 extends P2{
	
	protected  void m1(){
		
	}
	
}

//if p==private  c==cannot override 
// never use private for both parent and class

class P3{
	
	private void m1(){
		
	}
	
}
class C3 extends P3{
	
	public void m1(){
		
	}
	
}
public class visibility {

	
	
}
